import json
import sqlite3

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

from features import make_features, FEATURES, CAT

SQL = """
SELECT d.route_id, d.date, d.hour, d.passengers, d.scheduled_trips,
       w.rain_mm, w.temp_c,
       CASE WHEN h.date IS NULL THEN 0 ELSE 1 END AS is_holiday
FROM demand_hourly d
JOIN weather_daily w ON w.date = d.date
LEFT JOIN holidays h ON h.date = d.date
"""

con = sqlite3.connect("data/bmtc.db")
df = make_features(pd.read_sql(SQL, con))
con.close()
print("Rows loaded:", len(df))

# time-based split: train on the past, test on the future
train = df[df["date"] < "2025-07-01"]
test = df[df["date"] >= "2025-07-01"]
print("Train rows:", len(train), "| Test rows:", len(test))

# baseline: average passengers by route + hour + weekend
base = (train.groupby(["route_id", "hour", "is_weekend"])["passengers"]
        .mean().rename("pred").reset_index())
bt = test.merge(base, on=["route_id", "hour", "is_weekend"], how="left")
bt["pred"] = bt["pred"].fillna(train["passengers"].mean())
baseline_mae = mean_absolute_error(bt["passengers"], bt["pred"])


def build():
    return Pipeline([
        ("prep", ColumnTransformer(
            [("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), CAT)],
            remainder="passthrough")),
        ("gbr", HistGradientBoostingRegressor(max_iter=400, learning_rate=0.08,
                                              random_state=42)),
    ])


def fit(model, data):
    # target = passengers per scheduled trip; weights keep big hours important
    model.fit(data[FEATURES], data["passengers"] / data["scheduled_trips"],
              gbr__sample_weight=data["scheduled_trips"])
    return model


model = fit(build(), train)
pred = np.clip(model.predict(test[FEATURES]), 0, None) * test["scheduled_trips"].values

metrics = {
    "baseline_mae": float(baseline_mae),
    "model_mae": float(mean_absolute_error(test["passengers"], pred)),
    "model_rmse": float(np.sqrt(mean_squared_error(test["passengers"], pred))),
    "model_r2": float(r2_score(test["passengers"], pred)),
}
print("\nRESULTS (on unseen future data):")
for k, v in metrics.items():
    print(f"  {k}: {v:.3f}")

# refit on all data for deployment
model = fit(build(), df)
joblib.dump(model, "models/demand_model.joblib")
with open("models/metrics.json", "w") as f:
    json.dump(metrics, f, indent=2)
print("\nSaved: models/demand_model.joblib and models/metrics.json")