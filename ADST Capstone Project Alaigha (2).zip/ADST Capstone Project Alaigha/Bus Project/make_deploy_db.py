import os
import sqlite3

import pandas as pd

OUT = "data/bmtc_deploy.db"
src = sqlite3.connect("data/bmtc.db")
if os.path.exists(OUT):
    os.remove(OUT)
dst = sqlite3.connect(OUT)

for t in ["routes", "route_schedule", "gtfs_stops"]:
    pd.read_sql(f"SELECT * FROM {t}", src).to_sql(t, dst, index=False)

pd.read_sql("SELECT route_id, hour, ROUND(AVG(passengers), 1) AS passengers "
            "FROM demand_hourly GROUP BY route_id, hour", src
            ).to_sql("demand_hourly", dst, index=False)
dst.commit()
dst.close()
print("Created", OUT, "-", round(os.path.getsize(OUT) / 1e6, 1), "MB")