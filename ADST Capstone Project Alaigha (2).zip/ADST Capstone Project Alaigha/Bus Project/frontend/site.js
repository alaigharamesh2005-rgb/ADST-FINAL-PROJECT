// // (function () {
// //   const BRAND = "Demand Predictor";

// //   const originalFetch = window.fetch;
// //   window.fetch = async function (...args) {
// //     const res = await originalFetch.apply(this, args);
// //     if (res.status === 401) window.location.href = "/login";
// //     return res;
// //   };

// //   const path = location.pathname.replace(/index\.html$/, "");
// //   const links = [
// //     ["/", "Home"],
// //     ["/predict.html", "Predict"],
// //     ["/dashboard.html", "Dashboard"],
// //     ["/about.html", "About"]
// //   ];
// //   const nav = links.map(([href, label]) =>
// //     `<a href="${href}"${path === href ? ' class="active"' : ""}>${label}</a>`).join("");

// //   const header = document.createElement("header");
// //   header.className = "topbar";
// //   header.innerHTML = `
// //     <a class="brand" href="/">
// //       <span class="badge-logo">BMTC</span>
// //       <span class="brand-title">${BRAND}</span>
// //     </a>
// //     <nav class="nav">${nav}</nav>
// //     <div class="right">
// //       <span class="whoami" id="whoami"></span>
// //       <button class="logout" id="logoutBtn" type="button">Sign out</button>
// //     </div>`;
// //   document.body.prepend(header);

// //   document.getElementById("logoutBtn").addEventListener("click", async () => {
// //     await fetch("/api/logout", { method: "POST" });
// //     window.location.href = "/login";
// //   });
// //   fetch("/api/me")
// //     .then(r => r.ok ? r.json() : null)
// //     .then(d => { if (d && d.user) document.getElementById("whoami").textContent = "Signed in as " + d.user; })
// //     .catch(() => {});

// //   document.addEventListener("DOMContentLoaded", () => {
// //     const footer = document.createElement("footer");
// //     footer.className = "site-footer";
// //     footer.innerHTML = `
// //       <div class="footer-grid">
// //         <div>
// //           <h4>BMTC ${BRAND}</h4>
// //           <p>Predicts passenger demand for a BMTC route and hour, and flags routes that may need extra buses.</p>
// //         </div>
// //         <div>
// //           <h4>Pages</h4>
// //           ${links.map(([href, label]) => `<a href="${href}">${label}</a>`).join("")}
// //         </div>
// //         <div>
// //           <h4>Data</h4>
// //           <a href="https://github.com/Vonter/bmtc-gtfs" target="_blank" rel="noopener">BMTC GTFS (unofficial)</a>
// //           <span>Passenger demand: simulated</span>
// //         </div>
// //       </div>
// //       <div class="footer-bottom">© 2026 BMTC ${BRAND} · Student project · Not an official BMTC product</div>`;
// //     document.body.append(footer);
// //   });
// // })();

// (function () {
//   const BRAND = "Demand Predictor";

//   const originalFetch = window.fetch;
//   window.fetch = async function (...args) {
//     const res = await originalFetch.apply(this, args);
//     if (res.status === 401) window.location.href = "/";
//     return res;
//   };

//   const path = location.pathname;
//   const links = [
//     ["/home.html", "Home"],
//     ["/predict.html", "Predict"],
//     ["/dashboard.html", "Dashboard"],
//     ["/about.html", "About"]
//   ];
//   const nav = links.map(([href, label]) =>
//     `<a href="${href}"${path === href ? ' class="active"' : ""}>${label}</a>`).join("");

//   const header = document.createElement("header");
//   header.className = "topbar";
//   header.innerHTML = `
//     <a class="brand" href="/home.html">
//       <span class="badge-logo">BMTC</span>
//       <span class="brand-title">${BRAND}</span>
//     </a>
//     <nav class="nav">${nav}</nav>
//     <div class="right">
//       <span class="whoami" id="whoami"></span>
//       <button class="logout" id="logoutBtn" type="button">Sign out</button>
//     </div>`;
//   document.body.prepend(header);

//   document.getElementById("logoutBtn").addEventListener("click", async () => {
//     await fetch("/api/logout", { method: "POST" });
//     window.location.href = "/";
//   });
//   fetch("/api/me")
//     .then(r => r.ok ? r.json() : null)
//     .then(d => { if (d && d.user) document.getElementById("whoami").textContent = "Signed in as " + d.user; })
//     .catch(() => {});

//   document.addEventListener("DOMContentLoaded", () => {
//     const footer = document.createElement("footer");
//     footer.className = "site-footer";
//     footer.innerHTML = `
//       <div class="footer-grid">
//         <div>
//           <h4>BMTC ${BRAND}</h4>
//           <p>Predicts passenger demand for a BMTC route and hour, and flags routes that may need extra buses.</p>
//         </div>
//         <div>
//           <h4>Pages</h4>
//           ${links.map(([href, label]) => `<a href="${href}">${label}</a>`).join("")}
//         </div>
//         <div>
//           <h4>Data</h4>
//           <a href="https://github.com/Vonter/bmtc-gtfs" target="_blank" rel="noopener">BMTC GTFS (unofficial)</a>
//           <span>Passenger demand: simulated</span>
//         </div>
//       </div>
//       <div class="footer-bottom">© 2026 BMTC ${BRAND} · Student project · Not an official BMTC product</div>`;
//     document.body.append(footer);
//   });
// })();
(function () {
  const BRAND = "Demand Predictor";

  // if the session expires, send the user back to sign in
  const originalFetch = window.fetch;
  window.fetch = async function (...args) {
    const res = await originalFetch.apply(this, args);
    if (res.status === 401) window.location.href = "/login";
    return res;
  };

  const path = location.pathname === "/" ? "/home.html" : location.pathname;
  const links = [
    ["/home.html", "Home"],
    ["/predict.html", "Predict"],
    ["/dashboard.html", "Dashboard"],
    ["/about.html", "About"]
  ];
  const nav = links.map(([href, label]) =>
    `<a href="${href}"${path === href ? ' class="active"' : ""}>${label}</a>`).join("");

  const header = document.createElement("header");
  header.className = "topbar";
  header.innerHTML = `
    <a class="brand" href="/home.html">
      <span class="badge-logo">BMTC</span>
      <span class="brand-title">${BRAND}</span>
    </a>
    <nav class="nav">${nav}</nav>
    <div class="right">
      <span class="whoami" id="whoami"></span>
      <button class="logout" id="logoutBtn" type="button">Sign out</button>
    </div>`;
  document.body.prepend(header);

  document.getElementById("logoutBtn").addEventListener("click", async () => {
    await fetch("/api/logout", { method: "POST" });
    window.location.href = "/login";
  });

  fetch("/api/me")
    .then(r => r.ok ? r.json() : null)
    .then(d => { if (d && d.user) document.getElementById("whoami").textContent = "Signed in as " + d.user; })
    .catch(() => {});

  document.addEventListener("DOMContentLoaded", () => {
    const footer = document.createElement("footer");
    footer.className = "site-footer";
    footer.innerHTML = `
      <div class="footer-grid">
        <div>
          <h4>BMTC ${BRAND}</h4>
          <p>Predicts passenger demand for a BMTC route and hour, and flags routes that may need extra buses.</p>
        </div>
        <div>
          <h4>Pages</h4>
          ${links.map(([href, label]) => `<a href="${href}">${label}</a>`).join("")}
        </div>
        <div>
          <h4>Data</h4>
          <a href="https://github.com/Vonter/bmtc-gtfs" target="_blank" rel="noopener">BMTC GTFS (unofficial)</a>
          <span>Passenger demand: simulated</span>
        </div>
      </div>
      <div class="footer-bottom">© 2026 BMTC ${BRAND} · Student project · Not an official BMTC product</div>`;
    document.body.append(footer);
  });
})();