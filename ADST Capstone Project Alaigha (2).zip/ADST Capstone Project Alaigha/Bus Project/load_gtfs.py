import sqlite3
from pathlib import Path
import pandas as pd

GTFS = Path("data/raw/gtfs")
TOP_N = 100
ENC = "utf-8-sig"

routes = pd.read_csv(GTFS / "routes.txt", dtype=str, encoding=ENC)
trips = pd.read_csv(GTFS / "trips.txt", dtype=str, encoding=ENC)
stops = pd.read_csv(GTFS / "stops.txt", dtype=str, encoding=ENC)
cal = pd.read_csv(GTFS / "calendar.txt", dtype=str, encoding=ENC)
st = pd.read_csv(GTFS / "stop_times.txt", encoding=ENC, dtype=str,
                 usecols=["trip_id", "departure_time", "stop_id", "stop_sequence"])

# per trip: first departure hour, origin, destination, number of stops
st["stop_sequence"] = st["stop_sequence"].astype(int)
st = st.sort_values(["trip_id", "stop_sequence"])
g = st.groupby("trip_id")
trip_info = pd.DataFrame({
    "first_dep": g["departure_time"].first(),
    "origin_stop": g["stop_id"].first(),
    "dest_stop": g["stop_id"].last(),
    "n_stops": g.size(),
}).reset_index()
# GTFS times can exceed 24:00:00, so wrap with % 24
trip_info["hour"] = trip_info["first_dep"].str.split(":").str[0].astype(int) % 24

# which service runs on weekdays / weekends
days = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
for d in days:
    cal[d] = cal[d].astype(int)
cal["weekday"] = cal[days[:5]].max(axis=1)
cal["weekend"] = cal[days[5:]].max(axis=1)

df = (trips[["trip_id", "route_id", "service_id"]]
      .merge(trip_info, on="trip_id")
      .merge(cal[["service_id", "weekday", "weekend"]], on="service_id"))

# scheduled trips per route / day type / hour
parts = []
for dt in ["weekday", "weekend"]:
    s = df[df[dt] == 1].groupby(["route_id", "hour"]).size().rename("trips").reset_index()
    s["day_type"] = dt
    parts.append(s)
sched = pd.concat(parts)

# route summary and top N busiest routes
mode = lambda s: s.mode().iat[0]
summary = df.groupby("route_id").agg(origin_stop=("origin_stop", mode),
                                     dest_stop=("dest_stop", mode),
                                     n_stops=("n_stops", "median"),
                                     total_trips=("trip_id", "count")).reset_index()
summary = summary.merge(routes[["route_id", "route_short_name", "route_long_name"]], on="route_id")
top = summary.sort_values("total_trips", ascending=False).head(TOP_N)
sched = sched[sched["route_id"].isin(top["route_id"])]

# write to SQL
con = sqlite3.connect("data/bmtc.db")
top.to_sql("routes", con, if_exists="replace", index=False)
sched.to_sql("route_schedule", con, if_exists="replace", index=False)
stops.to_sql("gtfs_stops", con, if_exists="replace", index=False)
pd.read_csv("data/raw/bus_stops.csv", encoding_errors="replace").to_sql(
    "ward_stops", con, if_exists="replace", index=False)
con.close()

print(top[["route_id", "route_short_name", "route_long_name", "total_trips"]].head(10))
print("Saved: routes, route_schedule, gtfs_stops, ward_stops -> data/bmtc.db")