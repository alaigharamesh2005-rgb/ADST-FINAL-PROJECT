import os
import json
import math
import secrets
import sqlite3
from datetime import date as Date

import holidays
import joblib
import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from starlette.middleware.sessions import SessionMiddleware

from features import make_features, FEATURES

DB = "data/bmtc_deploy.db" if os.path.exists("data/bmtc_deploy.db") else "data/bmtc.db"
BUS_CAPACITY = 60  # effective passengers per trip (assumption)
model = joblib.load("models/demand_model.joblib")
KA_HOLIDAYS = holidays.India(subdiv="KA")

# ---- login settings ----
USERS = {
    "admin":   os.environ.get("APP_PASSWORD", "bmtc123"),
    "Alaigha": "225500",
    "user123": "12345",
    "user2":   "1234",
}
SECRET_KEY = os.environ.get("SECRET_KEY", "change-this-secret-key")

app = FastAPI(title="BMTC Demand Predictor")

PUBLIC_PATHS = {"/", "/login", "/login.html", "/api/login", "/favicon.ico"}


@app.middleware("http")
async def require_login(request: Request, call_next):
    path = request.url.path
    if path in PUBLIC_PATHS or request.session.get("user"):
        return await call_next(request)
    if path.startswith("/api/"):
        return JSONResponse({"detail": "Not logged in"}, status_code=401)
    return RedirectResponse("/login")


# must be added AFTER the login middleware so the session is available to it
# max_age=None -> cookie ends when the browser is closed
app.add_middleware(SessionMiddleware, secret_key=SECRET_KEY, max_age=None, same_site="lax")


def query(sql, params=()):
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    try:
        return [dict(r) for r in con.execute(sql, params)]
    finally:
        con.close()


class LoginReq(BaseModel):
    username: str
    password: str


class PredictReq(BaseModel):
    route_id: str
    date: Date
    hour: int
    rain_mm: float = 0
    temp_c: float = 26


@app.get("/")
def root(request: Request):
    if request.session.get("user"):
        return RedirectResponse("/home.html", status_code=303)
    return FileResponse("frontend/login.html")


@app.get("/login")
def login_page(request: Request):
    if request.session.get("user"):
        return RedirectResponse("/home.html", status_code=303)
    return FileResponse("frontend/login.html")


@app.post("/api/login")
def login(req: LoginReq, request: Request):
    expected = USERS.get(req.username)
    if expected is None or not secrets.compare_digest(req.password.encode(), expected.encode()):
        raise HTTPException(401, "Wrong username or password")
    request.session["user"] = req.username
    return {"ok": True}


@app.post("/api/logout")
def logout(request: Request):
    request.session.clear()
    return {"ok": True}


@app.get("/api/me")
def me(request: Request):
    return {"user": request.session.get("user")}


def get_route(route_id):
    r = query("SELECT * FROM routes WHERE route_id=?", (route_id,))
    if not r:
        raise HTTPException(404, "Unknown route")
    return r[0]


def schedule_for(route_id, d):
    """Scheduled trips per hour for this route on this date."""
    off = d.weekday() >= 5 or d in KA_HOLIDAYS
    day_type = "weekend" if off else "weekday"
    rows = query("SELECT hour, trips FROM route_schedule WHERE route_id=? AND day_type=?",
                 (route_id, day_type))
    sched = {int(r["hour"]): int(r["trips"]) for r in rows}
    if off and not sched:  # no weekend timetable: assume reduced weekday service
        rows = query("SELECT hour, trips FROM route_schedule "
                     "WHERE route_id=? AND day_type='weekday'", (route_id,))
        sched = {int(r["hour"]): max(1, round(int(r["trips"]) * 0.6)) for r in rows}
    return sched, day_type


def predict_hours(route_id, d, hours, rain, temp, sched):
    """Model predicts passengers per trip; multiply by scheduled trips."""
    trips = [sched.get(h, 0) for h in hours]
    df = pd.DataFrame({"route_id": route_id, "hour": hours})
    df["date"] = pd.Timestamp(d)
    df["rain_mm"], df["temp_c"] = rain, temp
    df["is_holiday"] = int(d in KA_HOLIDAYS)
    df["scheduled_trips"] = trips
    per_trip = model.predict(make_features(df)[FEATURES]).clip(0)
    return per_trip * pd.Series(trips).values


def advise(pred, sched):
    needed = math.ceil(pred / BUS_CAPACITY)
    if sched == 0:
        return {"required_trips": needed, "scheduled_trips": 0,
                "extra_trips_needed": needed, "utilisation_pct": None,
                "status": "NO_SERVICE"}
    util = pred / (sched * BUS_CAPACITY)
    status = "ADD_BUSES" if util > 1 else "WATCH" if util > 0.85 else "OK"
    return {"required_trips": needed, "scheduled_trips": sched,
            "extra_trips_needed": max(0, needed - sched),
            "utilisation_pct": round(util * 100, 1), "status": status}


@app.get("/api/routes")
def routes():
    return query("SELECT route_id, route_short_name, route_long_name, route_type "
                 "FROM routes ORDER BY total_trips DESC")


@app.get("/api/route-info/{route_id}")
def route_info(route_id: str):
    r = get_route(route_id)
    rows = query("SELECT stop_id, stop_name FROM gtfs_stops WHERE stop_id IN (?, ?)",
                 (r["origin_stop"], r["dest_stop"]))
    names = {x["stop_id"]: x["stop_name"] for x in rows}
    sched = query("SELECT day_type, hour, trips FROM route_schedule WHERE route_id=?",
                  (route_id,))
    summary = {}
    for dt in ("weekday", "weekend"):
        s = [x for x in sched if x["day_type"] == dt]
        summary[dt] = {
            "trips_per_day": sum(int(x["trips"]) for x in s),
            "first_hour": min((int(x["hour"]) for x in s), default=None),
            "last_hour": max((int(x["hour"]) for x in s), default=None),
            "busiest_hour": int(max(s, key=lambda x: x["trips"])["hour"]) if s else None,
        }
    return {"route_id": route_id,
            "bus_no": r["route_short_name"],
            "name": r["route_long_name"],
            "type": r["route_type"],
            "origin": names.get(r["origin_stop"], "n/a"),
            "destination": names.get(r["dest_stop"], "n/a"),
            "typical_stops": int(float(r["n_stops"])),
            "total_trips": int(r["total_trips"]),
            "schedule": summary}


@app.post("/api/predict")
def predict(req: PredictReq):
    get_route(req.route_id)
    sched, day_type = schedule_for(req.route_id, req.date)
    p = float(predict_hours(req.route_id, req.date, [req.hour],
                            req.rain_mm, req.temp_c, sched)[0])
    return {"predicted_passengers": round(p), "is_holiday": req.date in KA_HOLIDAYS,
            "day_type": day_type, **advise(p, sched.get(req.hour, 0))}


@app.post("/api/predict-day")
def predict_day(req: PredictReq):
    get_route(req.route_id)
    sched, _ = schedule_for(req.route_id, req.date)
    hrs = list(range(5, 23))
    preds = predict_hours(req.route_id, req.date, hrs, req.rain_mm, req.temp_c, sched)
    return {"hours": hrs,
            "predicted": [round(float(p)) if sched.get(h, 0) > 0 else None
                          for h, p in zip(hrs, preds)],
            "scheduled_trips": [sched.get(h, 0) for h in hrs],
            "capacity": [sched.get(h, 0) * BUS_CAPACITY for h in hrs]}


@app.get("/api/history/{route_id}")
def history(route_id: str):
    return query("SELECT hour, ROUND(AVG(passengers)) AS avg_passengers "
                 "FROM demand_hourly WHERE route_id=? GROUP BY hour ORDER BY hour",
                 (route_id,))


@app.get("/api/dashboard")
def dashboard(date: Date, rain_mm: float = 0, temp_c: float = 26):
    info = {r["route_id"]: r for r in query(
        "SELECT route_id, route_short_name, route_long_name FROM routes")}
    rows = []
    for rid in info:
        sched, _ = schedule_for(rid, date)
        for h, t in sched.items():
            if 5 <= h <= 22 and t > 0:
                rows.append({"route_id": rid, "hour": h, "scheduled_trips": t})
    if not rows:
        raise HTTPException(404, "No schedule data")

    df = pd.DataFrame(rows)
    df["date"] = pd.Timestamp(date)
    df["rain_mm"], df["temp_c"] = rain_mm, temp_c
    df["is_holiday"] = int(date in KA_HOLIDAYS)
    per_trip = model.predict(make_features(df)[FEATURES]).clip(0)
    df["pred"] = per_trip * df["scheduled_trips"]
    df["capacity"] = df["scheduled_trips"] * BUS_CAPACITY
    df["util"] = df["pred"] / df["capacity"]
    df["extra"] = (np.ceil(df["pred"] / BUS_CAPACITY) - df["scheduled_trips"]).clip(lower=0)

    peak = df.groupby("route_id")["util"].max()
    hourly = df.groupby("hour")[["pred", "capacity"]].sum().reindex(range(5, 23), fill_value=0)

    byr = (df.groupby("route_id").agg(pred=("pred", "sum"))
             .sort_values("pred", ascending=False).head(10).reset_index())
    top = [{"bus_no": info[r.route_id]["route_short_name"], "passengers": round(float(r.pred))}
           for r in byr.itertuples()]

    worst = df.loc[df.groupby("route_id")["util"].idxmax()]
    worst = worst[worst["util"] > 0.85].sort_values("util", ascending=False).head(15)
    action = [{"bus_no": info[r.route_id]["route_short_name"],
               "name": info[r.route_id]["route_long_name"],
               "peak_hour": int(r.hour), "predicted": round(float(r.pred)),
               "scheduled_trips": int(r.scheduled_trips),
               "extra_trips": int(r.extra),
               "utilisation_pct": round(float(r.util) * 100, 1),
               "status": "ADD_BUSES" if r.util > 1 else "WATCH"}
              for r in worst.itertuples()]

    return {
        "date": str(date), "is_holiday": date in KA_HOLIDAYS,
        "kpis": {"routes": len(info),
                 "total_passengers": round(float(df["pred"].sum())),
                 "routes_add_buses": int((peak > 1).sum()),
                 "routes_watch": int(((peak > 0.85) & (peak <= 1)).sum()),
                 "avg_utilisation_pct": round(float(df["pred"].sum() / df["capacity"].sum()) * 100, 1),
                 "extra_trips_total": int(df["extra"].sum())},
        "hourly": {"hours": list(range(5, 23)),
                   "predicted": [round(float(x)) for x in hourly["pred"]],
                   "capacity": [round(float(x)) for x in hourly["capacity"]]},
        "top_routes": top,
        "action_routes": action,
    }


@app.get("/api/yearly")
def yearly():
    """Yearly BMTC statistics from your Dataset 1."""
    try:
        raw = pd.read_csv("data/raw/bmtc_yearly.csv", encoding_errors="replace")
    except Exception:
        return {"years": [], "series": {}}
    names = raw.iloc[:, 0].astype(str).str.replace(r"\s+", " ", regex=True).str.lower()
    years = [str(c) for c in raw.columns[1:]]
    wanted = {"passengers_lakh": "passengers carried",
              "load_factor": "load factor",
              "vehicles_held": "vehicles held"}
    series = {}
    for key, pat in wanted.items():
        m = names.str.contains(pat)
        if m.any():
            vals = pd.to_numeric(raw.loc[m].iloc[0, 1:], errors="coerce")
            series[key] = [None if pd.isna(v) else float(v) for v in vals]
    return {"years": years, "series": series}


@app.get("/api/metrics")
def metrics():
    with open("models/metrics.json") as f:
        return json.load(f)


app.mount("/", StaticFiles(directory="frontend", html=True), name="frontend")