import pandas as pd

CAT = ["route_id"]
NUM = ["hour", "dow", "month", "year", "is_weekend", "is_holiday",
       "rain_mm", "temp_c", "scheduled_trips"]
FEATURES = CAT + NUM


def make_features(df):
    df = df.copy()
    d = pd.to_datetime(df["date"])
    df["dow"] = d.dt.dayofweek
    df["month"] = d.dt.month
    df["year"] = d.dt.year
    df["is_weekend"] = (df["dow"] >= 5).astype(int)
    return df