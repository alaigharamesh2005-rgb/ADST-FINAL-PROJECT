import sqlite3
import numpy as np
import pandas as pd
import holidays

rng = np.random.default_rng(42)
LOAD_PER_TRIP = 42          # average passengers per scheduled trip (assumption)
GROWTH_PER_YEAR = 0.05      # yearly ridership growth (assumption)

con = sqlite3.connect("data/bmtc.db")
routes = pd.read_sql("SELECT * FROM routes", con)
sched = pd.read_sql("SELECT * FROM route_schedule", con)


def classify(name):
    n = str(name).lower()
    if "kempegowda international" in n or "airport" in n or "kia" in n:
        return "airport"
    if any(k in n for k in ["electronic city", "itpl", "whitefield", "marathahalli",
                            "sarjapur", "bellandur", "silk board", "kadugodi", "hebbal"]):
        return "IT"
    if any(k in n for k in ["attibele", "bidadi", "nelamangala", "doddaballapur",
                            "anekal", "hoskote", "magadi", "kanakapura", "bagalur"]):
        return "suburban"
    return "city"


routes["route_type"] = routes["route_long_name"].apply(classify)
OFF_FACTOR = {"IT": 0.50, "airport": 0.90, "suburban": 0.80, "city": 0.75}

# ---- calendar: dates, weather (simulated), holidays ----
dates = pd.date_range("2023-01-01", "2025-12-31")
date_str = dates.strftime("%Y-%m-%d").values
month = dates.month.values
p_rain = np.where(np.isin(month, [6, 7, 8, 9, 10]), 0.45, 0.10)
rain = np.where(rng.random(len(dates)) < p_rain, rng.exponential(10, len(dates)), 0).round(1)
temp = (26 + 4 * np.sin((month - 3) / 12 * 2 * np.pi) + rng.normal(0, 1.5, len(dates))).round(1)
weather = pd.DataFrame({"date": date_str, "rain_mm": rain, "temp_c": temp})

hol = holidays.India(subdiv="KA", years=[2023, 2024, 2025])
hol_df = pd.DataFrame({"date": [d.strftime("%Y-%m-%d") for d in sorted(hol)],
                       "name": [hol[d] for d in sorted(hol)]})
is_off = (dates.dayofweek >= 5) | pd.Series(date_str).isin(hol_df["date"]).values


def profile(h):
    return (0.75 + 0.45 * np.exp(-((h - 9) / 1.8) ** 2)
                 + 0.40 * np.exp(-((h - 18) / 2.0) ** 2))


# ---- demand per route / date / hour ----
hours = np.arange(5, 23)
frames = []
for _, r in routes.iterrows():
    rid = r["route_id"]
    s = sched[sched["route_id"] == rid]
    tw, te = np.zeros(24), np.zeros(24)
    for _, row in s.iterrows():
        (tw if row["day_type"] == "weekday" else te)[int(row["hour"])] = row["trips"]
    if te.sum() == 0:
        te = tw * 0.6          # no weekend timetable found: assume reduced service
    if tw.sum() == 0:
        tw = te

    di, hh = np.meshgrid(np.arange(len(dates)), hours, indexing="ij")
    di, hh = di.ravel(), hh.ravel()
    trips = np.where(is_off[di], te[hh], tw[hh])
    keep = trips > 0
    di, hh, trips = di[keep], hh[keep], trips[keep]

    popularity = rng.lognormal(0, 0.25)      # fixed per route
    lam = (trips * LOAD_PER_TRIP * popularity * profile(hh)
           * np.where(is_off[di], OFF_FACTOR[r["route_type"]], 1.0)
           * (1 - 0.004 * np.minimum(rain[di], 30))
           * (1 + GROWTH_PER_YEAR * (dates.year.values[di] - 2023))
           * rng.normal(1, 0.08, len(di)))
    frames.append(pd.DataFrame({
        "route_id": rid, "date": date_str[di], "hour": hh,
        "scheduled_trips": trips.astype(int),
        "passengers": rng.poisson(np.clip(lam, 0, None))}))

demand = pd.concat(frames, ignore_index=True)

# ---- save to SQL ----
routes.to_sql("routes", con, if_exists="replace", index=False)
weather.to_sql("weather_daily", con, if_exists="replace", index=False)
hol_df.to_sql("holidays", con, if_exists="replace", index=False)
demand.to_sql("demand_hourly", con, if_exists="replace", index=False)
con.execute("CREATE INDEX IF NOT EXISTS idx_demand ON demand_hourly(route_id, date)")
con.commit()
con.close()

print("Rows in demand_hourly:", len(demand))
print(routes["route_type"].value_counts())
print(demand.groupby("hour")["passengers"].mean().round(0))